let search = document.querySelector('.search');
let searchInp = search.children[0];
let searchLbl = search.children[1];
let searchBtn = search.children[2];
let searchBrd = search.children[3];
let searchCls = search.children[4];
let searchTxt, clonedTxt, clonedLbl, clonedLblWrap, animating = false, busy = true;
let TLTxt = new TimelineLite();
let TLSrch = new TimelineLite({onReverseComplete: () => {
  TLTxt.clear();
  animating = false;
}});

createTxt('Enter a search query', searchLbl, 'search-text');
searchTxt = document.querySelectorAll('.search-text');

searchBtn.addEventListener('click', () => {
  if (!animating) animSearch();
});

searchBrd.addEventListener('click', () => {
  if (!animating) animSearch();
});

searchInp.addEventListener('focus', () => {
  if (busy || searchInp.value.trim().length) return;
  TLTxt.isActive() ? TLTxt.play() : TLTxt.restart().timeScale(1).staggerTo(searchTxt, .07, {opacity: 0}, .035); 
});

searchInp.addEventListener('blur', () => {
  if (busy || searchInp.value.trim().length) return;
  TLTxt.reverse().timeScale(1.3);
});

search.addEventListener('submit', e => {
  e.preventDefault();
  busy = true;
  TLTxt.paused() ? TLTxt.clear() : TLTxt.play();
  let val = searchInp.value.trim();
  searchInp.disabled = true;
  if (val.length) {
    cloneLbl();
    createLblTxt(val);
  }
  else TLSrch.reverse();
  searchInp.value = '';
  searchInp.blur();
});

searchCls.addEventListener('mousedown', e => {
  e.preventDefault();
});

searchCls.addEventListener('click', () => {
  if (busy) return;
  busy = true;
  let val = searchInp.value.trim();
  searchInp.disabled = true;
  if (val.length) {
    cloneLbl();
    createLblTxt(val);
  }
  else {
    TLTxt.isActive() ? TLTxt.play() : TLTxt.progress() == 1 ? TLTxt.clear() :
      TLTxt.restart().timeScale(1).staggerTo(searchTxt, .07, {opacity: 0}, .035);
    TLSrch.reverse();
  }
  searchInp.value = '';
  searchInp.blur();
});

function createTxt(text, elLbl, textClass) {
  let splitText = [];
  for (let i = text.length; i--;) {
    splitText.unshift(`<span class='${textClass}'>${text[i]}</span>`);
  }
  elLbl.innerHTML = splitText.join('');
};

function createLblTxt(val) {
  createTxt(val, clonedLbl, 'cloned-text');
  clonedTxt = document.querySelectorAll('.cloned-text');
  animClonedTxt(Array.from(clonedTxt).reverse());
}

function animSearch() {
  animating = true;
  TLSrch.restart()
  .to(searchBrd, .4, {scaleX: 2, x: -25, y: -25, ease: Sine.easeIn})
  .to(searchBtn, .4, {rotationX: 90, ease: Sine.easeIn}, '-=.4')
  .to(searchBrd, .4, {rotation: 180, x: '-=6', y: '+=10', ease: Power2.easeInOut})
  .set(searchBrd, {transformOrigin: '0', marginRight: '-38px'}) 
  .to(searchBrd, .6, {scaleX: 13, ease: Power1.easeOut})
  .set(search, {className: '+=edge', onComplete: showTxt})
  .to(searchInp, .6, {scaleX: 1, ease: Sine.easeInOut}, '-=.3')
  .set(searchCls, {className: '+=visible'})
  .addPause();
}

function showTxt() {
  let tl = new TimelineLite({onStart: () => {searchInp.disabled = true}});
  tl.staggerTo(searchTxt, .07, {opacity: 1}, .035);
  setTimeout(() => {
    searchInp.disabled = false;
    busy = false;
  }, 300)
}

function animClonedTxt(el) {
  let scrollW = clonedLbl.scrollWidth;
  let offsetW = scrollW - clonedLbl.offsetWidth;
  let tl = new TimelineLite({onComplete: () => {clonedLblWrap.remove()}});
  tl.staggerTo(el, .08, {opacity: 0}, .04);
  let tlDur = tl.totalDuration();
  let offsetTime = (offsetW * tlDur) / scrollW;
  if (offsetW > 0) {
    TweenLite.fromTo(clonedLbl, offsetTime, {x: -offsetW}, {x: 0, delay: .2, ease: SlowMo.ease.config(0.1, 0.1, false)});
  };
  setTimeout(() => {
    TLSrch.reverse();
  }, Math.max((tlDur - .35) * 1000, 0));
}

function cloneLbl() {
  clonedLblWrap = document.createElement('div');
  clonedLblWrap.className = 'search-label';
  search.appendChild(clonedLblWrap);
  clonedLbl = document.createElement('div');
  clonedLblWrap.appendChild(clonedLbl);
};

var options = {
  accessibility: true,
  prevNextButtons: true,
  pageDots: true,
  setGallerySize: false,
  arrowShape:{
      x0: 10,
      x1: 60,
      y1: 50,
      x2: 60,
      y2: 45,
      x3: 15
  }
};
var carousel = document.querySelector('[data-carousel]');
var slides = document.getElementsByClassName('carousel-cell');
var flkty = new Flickity(carousel, options);

flkty.on('scroll',function(){
  flkty.slides.forEach(function(slide, i){
      var image = slides[i];
      var x=(slide.target + flkty.x) * -1/3;
      image.style.backgroundPosition = x + 'px'
  });
})
$(document).ready(function(){
  $(".HoverB1").mouseover(function(){
    $(".BGH1").css("opacity", "1");
  });
  $(".HoverB1").mouseout(function(){
    $(".BGH1").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".HoverB2").mouseover(function(){
    $(".BGH2").css("opacity", "1");
  });
  $(".HoverB2").mouseout(function(){
    $(".BGH2").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".HoverB3").mouseover(function(){
    $(".BGH3").css("opacity", "1");
  });
  $(".HoverB3").mouseout(function(){
    $(".BGH3").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".swiper-viewportL").mouseover(function(){
    $(".BGH4").css("opacity", "1");
  });
  $(".swiper-viewportL").mouseout(function(){
    $(".BGH4").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".HoverB5").mouseover(function(){
    $(".BGH5").css("opacity", "1");
  });
  $(".HoverB5").mouseout(function(){
    $(".BGH5").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".HoverB6").mouseover(function(){
    $(".BGH6").css("opacity", "1");
  });
  $(".HoverB6").mouseout(function(){
    $(".BGH6").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".HoverB7").mouseover(function(){
    $(".BGH7").css("opacity", "1");
  });
  $(".HoverB7").mouseout(function(){
    $(".BGH7").css("opacity", "0");
  });
});

$(document).ready(function(){
  $(".HoverB8").mouseover(function(){
    $(".BGH8").css("opacity", "1");
  });
  $(".HoverB8").mouseout(function(){
    $(".BGH8").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB9").mouseover(function(){
    $(".BGH9").css("opacity", "1");
  });
  $(".HoverB9").mouseout(function(){
    $(".BGH9").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB10").mouseover(function(){
    $(".BGH10").css("opacity", "1");
  });
  $(".HoverB10").mouseout(function(){
    $(".BGH10").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB11").mouseover(function(){
    $(".BGH11").css("opacity", "1");
  });
  $(".HoverB11").mouseout(function(){
    $(".BGH11").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB12").mouseover(function(){
    $(".BGH12").css("opacity", "1");
  });
  $(".HoverB12").mouseout(function(){
    $(".BGH12").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB13").mouseover(function(){
    $(".BGH13").css("opacity", "1");
  });
  $(".HoverB13").mouseout(function(){
    $(".BGH13").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB14").mouseover(function(){
    $(".BGH14").css("opacity", "1");
  });
  $(".HoverB14").mouseout(function(){
    $(".BGH14").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB15").mouseover(function(){
    $(".BGH15").css("opacity", "1");
  });
  $(".HoverB15").mouseout(function(){
    $(".BGH15").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB16").mouseover(function(){
    $(".BGH16").css("opacity", "1");
  });
  $(".HoverB16").mouseout(function(){
    $(".BGH16").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB17").mouseover(function(){
    $(".BGH17").css("opacity", "1");
  });
  $(".HoverB17").mouseout(function(){
    $(".BGH17").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB18").mouseover(function(){
    $(".BGH18").css("opacity", "1");
  });
  $(".HoverB18").mouseout(function(){
    $(".BGH18").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB19").mouseover(function(){
    $(".BGH19").css("opacity", "1");
  });
  $(".HoverB19").mouseout(function(){
    $(".BGH19").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverB20").mouseover(function(){
    $(".BGH20").css("opacity", "1");
  });
  $(".HoverB20").mouseout(function(){
    $(".BGH20").css("opacity", "0");
  });
});
$(document).ready(function(){
  $(".HoverBoff7").mouseover(function(){
    $(".BGHoff7").css("opacity", "1");
  });
  $(".HoverBoff7").mouseout(function(){
    $(".BGHoff7").css("opacity", "0");
  });
});
  $(document).ready(function(){
  $(".HoverBoff8").mouseover(function(){
    $(".BGHoff8").css("opacity", "1");
  });
  $(".HoverBoff8").mouseout(function(){
    $(".BGHoff8").css("opacity", "0");
  });
});
// timer
(function () {
  const second = 1000,
        minute = second * 60,
        hour = minute * 60,
        day = hour * 24;

  let birthday = "Sep 30, 2023 00:00:00",
      countDown = new Date(birthday).getTime(),
      x = setInterval(function() {    

        let now = new Date().getTime(),
            distance = countDown - now;

        document.getElementById("days").innerText = Math.floor(distance / (day)),
          document.getElementById("hours").innerText = Math.floor((distance % (day)) / (hour)),
          document.getElementById("minutes").innerText = Math.floor((distance % (hour)) / (minute)),
          document.getElementById("seconds").innerText = Math.floor((distance % (minute)) / second);

        //do something later when date is reached
        if (distance < 0) {
          let headline = document.getElementById("headline"),
              countdown = document.getElementById("countdown"),
              content = document.getElementById("content");

          headline.innerText = "It's my birthday!";
          countdown.style.display = "none";
          content.style.display = "block";

          clearInterval(x);
        }
        //seconds
      }, 0)
  }());



//  setTimeout(function(){document.getElementById('FirstContainer').style.display='Block'},6000)  
    

function myFunction() {
      document.getElementById("FirstContainer").style.display="none";
      document.getElementById("Firstcontainerfluid").style.display="none";
}

function check(){
  var Name = document.getElementById('Name').value;
  var Email = document.getElementById('Email').value;
  var Subject = document.getElementById('Subject').value;
  var Text = document.getElementById('Text').value;
  if(Name==""){alert('please enter your name')}
  else(alert('Your Name Is : ' + ' ' + Name))
  if(Email==""){alert('please enter your e-mail')}
  else(alert('Your Email Is : ' + ' ' + Email))
  if(Subject==""){alert('please enter your subject')}
  else(alert('Your Subject Is : ' + ' ' + Subject))
  if(Text==""){alert('plz enter your txt')}
  else(alert('Your Text Is : ' + ' ' + Text))
  
}